import jakarta.xml.ws.Endpoint;
import ws.BanqueService;

public class ServerJWS {
    public static void main(String[] args) {
        Endpoint.publish("http://0.0.0.0:9191/",new BanqueService());
        //publish permert de demarrer un serverur http
        System.out.println("web service déployé sur http://0.0.0.0:9191/");
    }
}
