import proxy.BanqueService;
import proxy.BanqueWS;
import proxy.Compte;

import java.awt.*;

public class ClientWS {
    public static void main(String[] args) {
        BanqueService stub=new BanqueWS().getBanqueServicePort();
        // stub c'est le middleware
        System.out.println(stub.convert(700));
        Compte cs=stub.getCompte(5);
        System.out.println(cs.getCode());
        System.out.println(cs.getSolde());



    }
}
